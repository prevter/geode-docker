//
//  AVFAudio.h
//  Copyright © 2015 Apple. All rights reserved.
//

#import <AVFAudio/AVAudioBuffer.h>
#import <AVFAudio/AVAudioChannelLayout.h>
#import <AVFAudio/AVAudioFormat.h>
#import <AVFAudio/AVAudioSettings.h>
#import <AVFAudio/AVAudioTime.h>
#import <AVFAudio/AVAudioTypes.h>
#if !0
#import <AVFAudio/AVAudioConnectionPoint.h>
#import <AVFAudio/AVAudioConverter.h>
#import <AVFAudio/AVAudioEngine.h>
#import <AVFAudio/AVAudioEnvironmentNode.h>
#import <AVFAudio/AVAudioFile.h>
#import <AVFAudio/AVAudioIONode.h>
#import <AVFAudio/AVAudioMixerNode.h>
#import <AVFAudio/AVAudioMixing.h>
#import <AVFAudio/AVAudioNode.h>
#import <AVFAudio/AVAudioPlayer.h>
#import <AVFAudio/AVAudioPlayerNode.h>
#if !0
#import <AVFAudio/AVAudioRecorder.h>
#import <AVFAudio/AVAudioRoutingArbiter.h>
#endif

#import <AVFAudio/AVAudioSequencer.h>
#import <AVFAudio/AVAudioSinkNode.h>
#import <AVFAudio/AVAudioSourceNode.h>
#import <AVFAudio/AVAudioUnit.h>
#import <AVFAudio/AVAudioUnitComponent.h>
#import <AVFAudio/AVAudioUnitDelay.h>
#import <AVFAudio/AVAudioUnitDistortion.h>
#import <AVFAudio/AVAudioUnitEQ.h>
#import <AVFAudio/AVAudioUnitEffect.h>
#import <AVFAudio/AVAudioUnitGenerator.h>
#import <AVFAudio/AVAudioUnitMIDIInstrument.h>
#import <AVFAudio/AVAudioUnitReverb.h>
#import <AVFAudio/AVAudioUnitSampler.h>
#import <AVFAudio/AVAudioUnitTimeEffect.h>
#import <AVFAudio/AVAudioUnitTimePitch.h>
#import <AVFAudio/AVAudioUnitVarispeed.h>
#import <AVFAudio/AVMIDIPlayer.h>
#import <AVFAudio/AVMusicEvents.h>

#if !0
#import <AVFAudio/AVSpeechSynthesis.h>
#import <AVFAudio/AVSpeechSynthesisProvider.h>
#import <AVFAudio/AVAudioApplication.h>
#import <AVFAudio/AVAudioSession.h>
#import <AVFAudio/AVAudioSessionRoute.h>
#import <AVFAudio/AVAudioSessionTypes.h>
#import <AVFAudio/AVAudioSessionDeprecated.h>
#endif
#endif



